<?php

require_once '../models/CrudComentario.php';

if (isset($_GET['acaoi'])){
    $action = $_GET['acaoi'];
}else{
    $action = 'index';
}
switch ($action) {

    case 'comentar':

        $comentario = new Comentario($_POST['comentario_campo'], $_POST['id'], $_POST[''], $_POST['']);
        $crud = new CrudComentario();
        $crud->insertComentario($comentario);
        header('controladorUsuario.php?acaoi=comentario');

        break;
}

