<div id="container" class="ui container">
    <div class="ui comments center aligned">
        <div class="ui center aligned header">
        <h1>Comentários</h1>
        </div>
        <form method="post" class="ui form" action="controladorUsuario.php?acao=comentar">
            <input type="hidden" name="acao" value="comentar" >
            <div class="field">
                <textarea name="comentario_campo"></textarea>
            </div>
            <button type="submit" class="ui primary submit labeled icon button" value="comentar">
                <i class="icon edit" id="comentar"> </i>comentar
            </button>

        </form>
<?php
    $comentarioo = new CrudComentario();
    $comentarios = $comentarioo->getComentarios();
    foreach ($comentarios as $comentario): ?>

        <div class="comment">
        <a class="avatar">
            <img src="https://png.icons8.com/color/1600/avatar.png">
        </a>
        <div>
            <a class="author"></a>
            <?php $id = $comentario->getUsuarioIdusuario(); ?>
            <p><?= $comentarioo->getUsuario($id); ?></p>
            <div class="metadata">
                <p><?= $comentario->getData()?></p>
            </div>
            <div class="text">
                <p><?= $comentario->getTexto()?></p>
            </div>
            <div class="actions">
                <a class="reply"></a>
            </div>
        <i class="<?= ($_SESSION['admin'] && $_SESSION['admin']) ? "trash alternate outline icon large" : null ?>"></i>

        </div>
         </div>
<!---->
<!--        <!--    <form class="ui reply form">-->
<!--        <!--        <div class="field">-->
<!--        <!--            <textarea></textarea>-->
<!--        <!--        </div>-->
<!--        <!--        <div class="ui primary submit labeled icon button">-->
<!--        <!--            <i class="icon edit" id="comentar"> </i> responder-->
<!--        <!--        </div>-->
<!--        <!--    </form>-->
<!---->
    <?php endforeach; ?>

    </div>
</div>