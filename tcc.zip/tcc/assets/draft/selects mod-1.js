// ///////////////////AQUI COMEÇA O CARRO 1////////////////////////////
//
// $('#marca').change(function(){
//     if( $(this).val() ) {
//         $('#modelo').hide();
//         $('.carregando').show();
//
//
//         //http://localhost/tcc/app/controllers/controladorTab.php?marca=$(this).val()
//
//         $.getJSON('http://fipeapi.appspot.com/api/1/carros/veiculos/'+$(this).val()+'.json', function(j){
//                 var options = '<option value="">Selecione...</option>';
//                 for (var i = 0; i < j.length; i++) {
//                     options += '<option value="' +
//                         j[i].id + '">' +
//                         j[i].name + '</option>';
//                 }
//                 $('#modelo').html(options).show();
//                 $('.carregando').hide();
//             });
//     } else {
//         $('#modelo').html(
//             '<option value="">-- Escolha uma montadora --</option>'
//         );
//     }
// });
//
// $('#modelo').change(function(){
//     if( $(this).val() ) {
//         $('#ano').hide();
//         $('.carregando').show();
//         $.getJSON(
//             'http://fipeapi.appspot.com/api/1/carros/veiculo/'+$('#marca').val()+'/'+$(this).val()+'.json', function(j){
//                 var options = '<option value="">Selecione...</option>';
//                 for (var i = 0; i < j.length; i++) {
//                     options += '<option value="' +
//                         j[i].id + '">' +
//                         j[i].name + '</option>';
//                 }
//                 $('#ano').html(options).show();
//                 $('.carregando').hide();
//             });
//     } else {
//         $('#ano').html(
//             '<option value="">-- Escolha um modelo --</option>'
//         );
//     }
// });
// ///////////////////////////////AQUI COMEÇA O CARRO 2////////////////////////////////////
//
// $('#marca1').change(function(){
//     if( $(this).val() ) {
//         $('#modelo1').hide();
//         $('.carregando').show();
//
//
//         //http://localhost/tcc/app/controllers/controladorTab.php?marca=$(this).val()
//
//         $.getJSON('http://fipeapi.appspot.com/api/1/carros/veiculos/'+$(this).val()+'.json', function(j){
//             var options = '<option value="">Selecione...</option>';
//             for (var i = 0; i < j.length; i++) {
//                 options += '<option value="' +
//                     j[i].id + '">' +
//                     j[i].name + '</option>';
//             }
//             $('#modelo1').html(options).show();
//             $('.carregando').hide();
//         });
//     } else {
//         $('#modelo1').html(
//             '<option value="">-- Escolha uma montadora --</option>'
//         );
//     }
// });
//
// $('#modelo1').change(function(){
//     if( $(this).val() ) {
//         $('#ano1').hide();
//         $('.carregando').show();
//         $.getJSON(
//             'http://fipeapi.appspot.com/api/1/carros/veiculo/'+$('#marca1').val()+'/'+$(this).val()+'.json', function(j){
//                 var options = '<option value="">Selecione...</option>';
//                 for (var i = 0; i < j.length; i++) {
//                     options += '<option value="' +
//                         j[i].id + '">' +
//                         j[i].name + '</option>';
//                 }
//                 $('#ano1').html(options).show();
//                 $('.carregando').hide();
//             });
//     } else {
//         $('#ano1').html(
//             '<option value="">-- Escolha um modelo --</option>'
//         );
//     }
// });
//
// /////////////////////////////////////AQUI COMEÇA O CARRO 3///////////////////////////////////////
//
// $('#marca2').change(function(){
//     if( $(this).val() ) {
//         $('#modelo2').hide();
//         $('.carregando').show();
//
//
//         //http://localhost/tcc/app/controllers/controladorTab.php?marca=$(this).val()
//
//         $.getJSON('http://fipeapi.appspot.com/api/1/carros/veiculos/'+$(this).val()+'.json', function(j){
//             var options = '<option value="">Selecione...</option>';
//             for (var i = 0; i < j.length; i++) {
//                 options += '<option value="' +
//                     j[i].id + '">' +
//                     j[i].name + '</option>';
//             }
//             $('#modelo2').html(options).show();
//             $('.carregando').hide();
//         });
//     } else {
//         $('#modelo2').html(
//             '<option value="">-- Escolha uma montadora --</option>'
//         );
//     }
// });
//
// $('#modelo2').change(function(){
//     if( $(this).val() ) {
//         $('#ano').hide();
//         $('.carregando').show();
//         $.getJSON(
//             'http://fipeapi.appspot.com/api/1/carros/veiculo/'+$('#marca2').val()+'/'+$(this).val()+'.json', function(j){
//                 var options = '<option value="">Selecione...</option>';
//                 for (var i = 0; i < j.length; i++) {
//                     options += '<option value="' +
//                         j[i].id + '">' +
//                         j[i].name + '</option>';
//                 }
//                 $('#ano2').html(options).show();
//                 $('.carregando').hide();
//             });
//     } else {
//         $('#ano2').html(
//             '<option value="">-- Escolha um modelo --</option>'
//         );
//     }
// });
//
// //AQUI COMEÇA O CARRO 4
//
// $('#marca3').change(function(){
//     if( $(this).val() ) {
//         $('#modelo3').hide();
//         $('.carregando').show();
//
//
//         //http://localhost/tcc/app/controllers/controladorTab.php?marca=$(this).val()
//
//         $.getJSON('http://fipeapi.appspot.com/api/1/carros/veiculos/'+$(this).val()+'.json', function(j){
//             var options = '<option value="">Selecione...</option>';
//             for (var i = 0; i < j.length; i++) {
//                 options += '<option value="' +
//                     j[i].id + '">' +
//                     j[i].name + '</option>';
//             }
//             $('#modelo3').html(options).show();
//             $('.carregando').hide();
//         });
//     } else {
//         $('#modelo3').html(
//             '<option value="">-- Escolha uma montadora --</option>'
//         );
//     }
// });
//
// $('#modelo3').change(function(){
//     if( $(this).val() ) {
//         $('#ano3').hide();
//         $('.carregando').show();
//         $.getJSON(
//             'http://fipeapi.appspot.com/api/1/carros/veiculo/'+$('#marca3').val()+'/'+$(this).val()+'.json', function(j){
//                 var options = '<option value="">Selecione...</option>';
//                 for (var i = 0; i < j.length; i++) {
//                     options += '<option value="' +
//                         j[i].id + '">' +
//                         j[i].name + '</option>';
//                 }
//                 $('#ano3').html(options).show();
//                 $('.carregando').hide();
//             });
//     } else {
//         $('#ano3').html(
//             '<option value="">-- Escolha um modelo --</option>'
//         );
//     }
// });