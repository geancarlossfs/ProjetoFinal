<?php
    header("location: app/controllers/controladorUsuario.php?acao=index");
?>