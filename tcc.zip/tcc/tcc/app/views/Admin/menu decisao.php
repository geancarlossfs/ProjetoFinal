
    <div class="ui six item menu">
        <a class="item lic" href="controladorUsuario.php?acao=index">Início</a>
        <a class="item lic" href="?acao=decisao" style="<?=($_GET['acao'] == 'decisao') ? 'background-color: #37AAE8 !important;' : ''?>">Admin</a>
        <div class="ui dropdown simple item">
            <span class="text">Usuarios</span>
            <i class="dropdown icon"></i>
            <div class="menu">
                <div class="header">Categories</div>
                <a class="item" href="?acao=lista">Lista</a>
                <a class="item" href="?acao=cadastro">Cadastro</a>
            </div>
        </div>
        <div class="ui dropdown simple item">
            <span class="text">Montadoras</span>
            <i class="dropdown icon"></i>
            <div class="menu">
                <div class="header">Categories</div>
                <a class="item" href="?acao=montadoras">Lista</a>
                <a class="item" href="?acao=cadastromontadoras">Cadastro</a>
            </div>
        </div>
        <a class="item lic" href="?acao=">Modelos</a>
        <a class="item lic" href="?acao=">Ano Modelo</a>
    </div>
