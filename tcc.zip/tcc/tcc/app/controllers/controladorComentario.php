<?php

require_once '../models/CrudComentario.php';

if (isset($_GET['acaoi'])){
    $action = $_GET['acaoi'];
}else{
    $action = 'index';
}
switch ($action) {

    case 'comentar':

        $comentario = new Comentario($_POST['comentario_campo'], $_POST['id']);
        $crud = new CrudComentario();
        $crud->insertComentario($comentario);
        header('location: ../../views/Usuario/comentario.php?acaoi=comentar');

        break;
}

