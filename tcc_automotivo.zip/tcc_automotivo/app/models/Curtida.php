<?php

class Curtida
{
    private $idcurtida;
    private $modelo_ano_idmodelo_ano;
    private $usuario_idusuario;

    public function __construct($idcurtida, $modelo_ano_idmodelo_ano, $usuario_idusuario)
    {
        $this->idcurtida = $idcurtida;
        $this->modelo_ano_idmodelo_ano = $modelo_ano_idmodelo_ano;
        $this->usuario_idusuario = $usuario_idusuario;
    }

    /**
     * @return mixed
     */
    public function getIdcurtida()
    {
        return $this->idcurtida;
    }

    /**
     * @param mixed $idcurtida
     */
    public function setIdcurtida($idcurtida): void
    {
        $this->idcurtida = $idcurtida;
    }

    /**
     * @return mixed
     */
    public function getModeloAnoIdmodeloAno()
    {
        return $this->modelo_ano_idmodelo_ano;
    }

    /**
     * @param mixed $modelo_ano_idmodelo_ano
     */
    public function setModeloAnoIdmodeloAno($modelo_ano_idmodelo_ano): void
    {
        $this->modelo_ano_idmodelo_ano = $modelo_ano_idmodelo_ano;
    }

    /**
     * @return mixed
     */
    public function getUsuarioIdusuario()
    {
        return $this->usuario_idusuario;
    }

    /**
     * @param mixed $usuario_idusuario
     */
    public function setUsuarioIdusuario($usuario_idusuario): void
    {
        $this->usuario_idusuario = $usuario_idusuario;
    }


}