<!-- FOOTER -->
<div class="space"></div>
<div class="ui inverted vertical footer segment form-page">
    <div class="ui container center aligned">
        Compare Cars 2018. Todos direitos reservados
    </div>
</div>
</div>
</body>
</html>