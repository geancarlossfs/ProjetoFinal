   <html>

    <div id="container" class="ui container">
        <div class="ui comments small">
            <div class="ui center aligned header">
                <h1>Comentários</h1>
            </div>
            <form method="post" class="ui form" action="controladorUsuario.php?acao=comentar">
                <input type="hidden" name="acao" value="comentar" >
                <div class="field">
                    <textarea name="comentario_campo"></textarea>
                </div>
                <button type="submit" class="ui primary submit labeled icon button" value="comentar">
                    <i class="icon edit" id="comentar"> </i>comentar
                </button>

            </form>
            <?php
            $comentarioo = new CrudComentario();
            $comentarios = $comentarioo->getComentarios();
            $pend = $comentarios[0]->getPendente();
            if($pend[0] == 3){
                echo('<h1 class="ui header center aligned">Sem comentários</h1>');
            }
            else {
                foreach ($comentarios as $comentario): ?>

                    <div class="ui divider"></div>
                    <div class="comment">
                        <a class="avatar">
                            <img src="https://png.icons8.com/color/1600/avatar.png">
                        </a>
                        <div>
                            <?php $id = $comentario->getUsuarioIdusuario() ?>
                            <p><?= $comentarioo->getUsuarioEmail($id) ?></p>
                            <div class="metadata">
                                <p><?= $comentario->getData() ?></p>
                            </div>
                            <div class="text">
                                <p><?= $comentario->getTexto() ?></p>
                            </div>

                            <?php
                            if (esta_logado() && e_admin()) {
                                ?>
                                <a href="controladorAdmin.php?acao=excluircomentario&codigocom=<?= $comentario->getIdcomentario() ?>"
                                   class="ui submit icon labeled red button">
                                    <i class="trash alternate outline icon large"></i>Excluir
                                </a>
                                <?php
                            } ?>
                        </div>
                    </div>
                    <!---->
                    <!--        <!--    <form class="ui reply form">-->
                    <!--        <!--        <div class="field">-->
                    <!--        <!--            <textarea></textarea>-->
                    <!--        <!--        </div>-->
                    <!--        <!--        <div class="ui primary submit labeled icon button">-->
                    <!--        <!--            <i class="icon edit" id="comentar"> </i> responder-->
                    <!--        <!--        </div>-->
                    <!--        <!--    </form>-->
                    <!---->
                <?php endforeach;
            }?>

        </div>
    </div>

    <!-- FOOTER -->
    <div class="space"></div>
    <div class="ui inverted vertical footer segment form-page">
        <div class="ui container center aligned">
            Compare Cars 2018. Todos direitos reservados
        </div>
    </div>
    </div>
    </body>
    </html>