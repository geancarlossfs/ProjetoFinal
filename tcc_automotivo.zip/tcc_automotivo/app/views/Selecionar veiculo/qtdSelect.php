    <div style="padding-top: 10%!important;" class="ui center aligned header">
        <h1 style="font-family: jellee">Quantos carros deseja comparar?</h1>
    </div>
    <div style="background-color: #1b1c1d;" class="ui center aligned three column grid segment">
        <div class="column">
            <a href="controladorComparacao.php?acao=comp2"><button class="red massive ui button">2</button></a>
        </div>
        <div class="column">
            <a href="controladorComparacao.php?acao=comp3"><button class="orange massive ui button">3</button></a>
        </div>
        <div class="column">
            <a href="controladorComparacao.php?acao=comp4"><button class=" green massive ui button">4</button></a>
        </div>
    </div>
    </body>
    </html>