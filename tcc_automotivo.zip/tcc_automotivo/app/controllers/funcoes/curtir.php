<?php

    session_start();
    require_once "../../models/CrudCurtidas.php";

    $id = $_POST['id'];
    $iduser = $_SESSION['id'];
    $crud = new CrudCurtidas();
    $comprovar = $crud->VerificaCurtida($id, $iduser);
    $count = $comprovar['COUNT(idcurtida)'];

    if($count == 0){
        $crud->InsertCurtida($id, $iduser);
    }else{
        $crud->DeleteCurtida($id, $iduser);
    }
    $contar = $crud->NCurtidas($id);
    $cont = $contar['COUNT(idcurtida)'];

    if($count >=1){$gostou = 'Gostei'; $cont = $cont++;}else{$gostou = 'Não Gostei'; $cont = $cont--;}

    $dados = array('likes' =>$cont, 'text' =>$gostou);
    echo json_encode($dados);