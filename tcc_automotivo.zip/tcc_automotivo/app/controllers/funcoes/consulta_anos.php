<?php

require_once "../../models/CrudModelo.php";
require_once "../../models/DBConexao.php";

$id_modelo = $_GET['idmodelo'];
$crud = new CrudModelo();
$anos = $crud->getAnosPorModelo($id_modelo);
header('Content-Type: application/json');
echo json_encode($anos);