<?php

    require_once "../../models/CrudModelo.php";
    require_once "../../models/DBConexao.php";

    $id_veiculo = $_GET['idveiculo'];
    $crud = new CrudModelo();
    $detalhes = $crud->getDetalhesVeiculo($id_veiculo);
    header('Content-Type: application/json');
    echo json_encode($detalhes);